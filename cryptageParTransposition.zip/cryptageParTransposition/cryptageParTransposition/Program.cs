﻿using System;

namespace cryptageParTransposition
{


    internal class Program
    {
        public static string[,] secret;
        public static string key;
        public static string String;



        static void Main(string[] args)
        {
            Console.WriteLine("Programme de cryptage par transposition");
            run();
        }

        static void spy(string[,] mat)
        {
            for (int i = 0; i < mat.GetLength(0); i++)
            {
                for (int j = 0; j < mat.GetLength(1); j++)
                {
                    Console.Write(mat[i, j] + '|');
                }
                Console.Write("\n");
            }
        }

        static void run()
        {
                try
                {
                    Console.Write("Entrez la clée secrète C> ");
                    key = Console.ReadLine();
                    if(key != null)
                    {
                        Console.Write("Entrez la phrase à protéger C> ");
                        String = Console.ReadLine();
                        if (String != null)
                        {
                            cleaner();
                        }
                        else
                        {
                            Console.WriteLine("L'entrée ne peut pas être null");
                        }
                    }
                    else
                    {
                        Console.WriteLine("La clée ne peut pas être null");

                    }
                }
                catch
                {
                    Console.WriteLine("Entrée INVALIDE ");
                }
        }

        static void cleaner()
        {
            string buffer = "";
            for(int i = 0; i < String.Length; i++)
            {
                if(String[i] != ' ')
                {
                    buffer += String[i];
                }
                else
                {
                    buffer += "";
                }
            }
            String = buffer;
            createMatrice();
        }

        static void createMatrice()
        {
            int x = key.Length;
            int y = (int)(String.Length / key.Length) + 1; // le + 1 est pour pouvoir mettre le clée tout en haut !
            if(String.Length % key.Length != 0)
            {
                y += 1;
            }
            Console.WriteLine(y);
            secret = new string[key.Length, y];
            generate();
        }

        static void generate()
        {
            Console.WriteLine("Dans générate");
            //première ligne = key
            for(int i = 0; i < key.Length; i++)
            {
                secret[0, i] = key[i].ToString();
            }

            for(int i =1; i < secret.GetLength(0); i++)
            {
                for(int j =0; j < secret.GetLength(1); j++)
                {
                    secret[i, j] = String[].ToString();
                }
            }
            spy(secret);

        }
    }
}
